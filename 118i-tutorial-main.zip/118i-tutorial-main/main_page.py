import streamlit as st

st.markdown("# Main page 🎈")
st.sidebar.markdown("# Main page 🎈")

message = "Welcome to the main page! 🎉\nPlease navigate the pages to explroe some sample code."
st.write(message)